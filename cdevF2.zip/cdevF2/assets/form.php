<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Validate POST request method
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    echo json_encode(["status" => "error", "message" => "Invalid request method."]);
    exit;
}

// Declare variables
$name = $_POST["name"];
$email = $_POST["email"];
$message = $_POST["message"];

// Import PHPMailer classes into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

header('Content-Type: application/json');

// Validate the required fields
if (empty($name) || empty($email) || empty($message)) {
    echo json_encode(["status" => "error", "message" => "Please fill in all required fields."]);
    exit;
}

// Validate the email address
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["status" => "error", "message" => "Invalid email format."]);
    exit;
}

// Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                       // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'alverachantraveden@gmail.com';          // SMTP username
    $mail->Password   = 'hjdbvaibftufctrx';                // SMTP password (Use environment variable)
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            // Enable implicit TLS encryption
    $mail->Port       = 465;                                    // TCP port to connect to

    // Recipients
    $mail->setFrom('chariskimberly14@gmail.com', 'CDEV');       // FIXED missing quote
    $mail->addAddress('chariskimberly14@gmail.com', 'CDEV');    // Main recipient

    // email format to HTML
    $mail->isHTML(true);

    // Custom mail subject and template
    $subject = "New message from $name";

    // Load mail template and replace placeholders
    $emailtempTemplate = file_get_contents('../emailtemp.html');
    $emailtempTemplate = str_replace(
        ['{name}', '{email}', '{message}'],
        [$name, $email, $message],
        $emailtempTemplate
    );

    // Set mail subject and body
    $mail->Subject = $subject;
    $mail->Body    = $emailtempTemplate;

    // Send the email
     if ($mail->send()) {
        // If email is sent successfully, redirect to the response page
        header('Location: /response/response.html');  // Path to your response page
        exit();  // Stop script execution after redirection
    } else {
        echo 'Mailer Error: ' . $mail->ErrorInfo;     // Output error if email is not sent
    }
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>