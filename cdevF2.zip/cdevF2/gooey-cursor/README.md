# Gooey Cursor

A Pen created on CodePen.io. Original URL: [https://codepen.io/icomgroup/pen/gOVMPjQ](https://codepen.io/icomgroup/pen/gOVMPjQ).

