try {
    // Database credentials
    $host = 'localhost';
    $db = 'cdevelo1_blanco';
    $user = 'cpses_cdeylwdtbv@localhost';
    $pass = '';

    // Establish database connection
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Increment visit count
    $stmt = $pdo->prepare("UPDATE visit_count SET count = count + 1 WHERE id = 1");
    $stmt->execute();

    // Fetch the updated visit count
    $stmt = $pdo->query("SELECT count FROM visit_count WHERE id = 1");
    $count = $stmt->fetchColumn();

    if ($count === false) {
        echo "No count found.";
    } else {
        echo "<p style='color: grey; font-size: 18px;'>Total visits: <span style='color: goldenrod;'>$count</span></p>";
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
